
(cl:in-package :asdf)

(defsystem "arm_remote-msg"
  :depends-on (:roslisp-msg-protocol :roslisp-utils :actionlib_msgs-msg
               :std_msgs-msg
)
  :components ((:file "_package")
    (:file "DeltabotTaskAction" :depends-on ("_package_DeltabotTaskAction"))
    (:file "_package_DeltabotTaskAction" :depends-on ("_package"))
    (:file "DeltabotTaskActionFeedback" :depends-on ("_package_DeltabotTaskActionFeedback"))
    (:file "_package_DeltabotTaskActionFeedback" :depends-on ("_package"))
    (:file "DeltabotTaskActionGoal" :depends-on ("_package_DeltabotTaskActionGoal"))
    (:file "_package_DeltabotTaskActionGoal" :depends-on ("_package"))
    (:file "DeltabotTaskActionResult" :depends-on ("_package_DeltabotTaskActionResult"))
    (:file "_package_DeltabotTaskActionResult" :depends-on ("_package"))
    (:file "DeltabotTaskFeedback" :depends-on ("_package_DeltabotTaskFeedback"))
    (:file "_package_DeltabotTaskFeedback" :depends-on ("_package"))
    (:file "DeltabotTaskGoal" :depends-on ("_package_DeltabotTaskGoal"))
    (:file "_package_DeltabotTaskGoal" :depends-on ("_package"))
    (:file "DeltabotTaskResult" :depends-on ("_package_DeltabotTaskResult"))
    (:file "_package_DeltabotTaskResult" :depends-on ("_package"))
  ))