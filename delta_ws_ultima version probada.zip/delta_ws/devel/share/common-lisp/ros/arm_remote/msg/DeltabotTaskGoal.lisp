; Auto-generated. Do not edit!


(cl:in-package arm_remote-msg)


;//! \htmlinclude DeltabotTaskGoal.msg.html

(cl:defclass <DeltabotTaskGoal> (roslisp-msg-protocol:ros-message)
  ((target_group
    :reader target_group
    :initarg :target_group
    :type cl:string
    :initform "")
   (target_position
    :reader target_position
    :initarg :target_position
    :type (cl:vector cl:float)
   :initform (cl:make-array 0 :element-type 'cl:float :initial-element 0.0)))
)

(cl:defclass DeltabotTaskGoal (<DeltabotTaskGoal>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <DeltabotTaskGoal>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'DeltabotTaskGoal)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name arm_remote-msg:<DeltabotTaskGoal> is deprecated: use arm_remote-msg:DeltabotTaskGoal instead.")))

(cl:ensure-generic-function 'target_group-val :lambda-list '(m))
(cl:defmethod target_group-val ((m <DeltabotTaskGoal>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader arm_remote-msg:target_group-val is deprecated.  Use arm_remote-msg:target_group instead.")
  (target_group m))

(cl:ensure-generic-function 'target_position-val :lambda-list '(m))
(cl:defmethod target_position-val ((m <DeltabotTaskGoal>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader arm_remote-msg:target_position-val is deprecated.  Use arm_remote-msg:target_position instead.")
  (target_position m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <DeltabotTaskGoal>) ostream)
  "Serializes a message object of type '<DeltabotTaskGoal>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'target_group))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'target_group))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'target_position))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((bits (roslisp-utils:encode-double-float-bits ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream)))
   (cl:slot-value msg 'target_position))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <DeltabotTaskGoal>) istream)
  "Deserializes a message object of type '<DeltabotTaskGoal>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'target_group) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'target_group) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'target_position) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'target_position)))
    (cl:dotimes (i __ros_arr_len)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:aref vals i) (roslisp-utils:decode-double-float-bits bits))))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<DeltabotTaskGoal>)))
  "Returns string type for a message object of type '<DeltabotTaskGoal>"
  "arm_remote/DeltabotTaskGoal")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'DeltabotTaskGoal)))
  "Returns string type for a message object of type 'DeltabotTaskGoal"
  "arm_remote/DeltabotTaskGoal")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<DeltabotTaskGoal>)))
  "Returns md5sum for a message object of type '<DeltabotTaskGoal>"
  "50e89794ba772389667ccd0a2e0fb600")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'DeltabotTaskGoal)))
  "Returns md5sum for a message object of type 'DeltabotTaskGoal"
  "50e89794ba772389667ccd0a2e0fb600")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<DeltabotTaskGoal>)))
  "Returns full string definition for message of type '<DeltabotTaskGoal>"
  (cl:format cl:nil "# ====== DO NOT MODIFY! AUTOGENERATED FROM AN ACTION DEFINITION ======~%# Goal~%string target_group~%float64[] target_position~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'DeltabotTaskGoal)))
  "Returns full string definition for message of type 'DeltabotTaskGoal"
  (cl:format cl:nil "# ====== DO NOT MODIFY! AUTOGENERATED FROM AN ACTION DEFINITION ======~%# Goal~%string target_group~%float64[] target_position~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <DeltabotTaskGoal>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'target_group))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'target_position) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 8)))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <DeltabotTaskGoal>))
  "Converts a ROS message object to a list"
  (cl:list 'DeltabotTaskGoal
    (cl:cons ':target_group (target_group msg))
    (cl:cons ':target_position (target_position msg))
))
