(cl:in-package arm_remote-msg)
(cl:export '(TARGET_GROUP-VAL
          TARGET_GROUP
          TARGET_POSITION-VAL
          TARGET_POSITION
))