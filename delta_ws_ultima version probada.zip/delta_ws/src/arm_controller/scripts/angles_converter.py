#!/usr/bin/env python3
import rospy
import math
from arm_controller.srv import AnglesConverter, AnglesConverterResponse

def convert_radians_to_degrees(req):
    res = AnglesConverterResponse()
    res.base = ((req.base + (math.pi/2)) * 180) / math.pi
    res.humerus = ((req.humerus + (math.pi/2)) * 180) / math.pi
    res.forearm = ((req.forearm + (math.pi/2)) * 180) / math.pi
    res.left_gear = (req.left_gear * 180) / math.pi
    res.right_gear = (req.right_gear * 180) / math.pi
    res.gripper = (req.gripper * 180) / math.pi
    res.ubracket = ((req.ubracket + (math.pi/2)) * 180) / math.pi        
    res.endeffector = (req.endeffector * 180) / math.pi                 
    return res

def convert_degrees_to_radians(req):
    res = AnglesConverterResponse()
    res.base = ((req.base * math.pi) / 180) - (math.pi/2)
    res.humerus = ((req.humerus * math.pi) / 180) - (math.pi/2)
    res.forearm = ((req.forearm * math.pi) / 180) - (math.pi/2)
    res.left_gear = (req.left_gear * math.pi) / 180
    res.right_gear = (req.right_gear * math.pi) / 180
    res.gripper = (req.gripper * math.pi) / 180
    res.ubracket = ((req.ubracket * math.pi) / 180) - (math.pi/2)        
    res.endeffector = (req.endeffector * math.pi) / 180                 
    return res

if __name__ == "__main__":
    rospy.init_node('angles_converter')
    rospy.Service('radians_to_degrees', AnglesConverter, convert_radians_to_degrees)
    rospy.Service('degrees_to_radians', AnglesConverter, convert_degrees_to_radians)
    rospy.loginfo("Servicio de conversión activo (Python)")
    rospy.spin()
