(cl:in-package arm_remote-msg)
(cl:export '(SUCCESS-VAL
          SUCCESS
))