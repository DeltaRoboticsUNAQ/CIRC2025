#include "ros/ros.h"
#include "arm_controller/AnglesConverter.h"
#include <math.h>

bool convert_radians_to_degrees(arm_controller::AnglesConverter::Request &req,
                                arm_controller::AnglesConverter::Response &res) {
    res.base = ((req.base + (M_PI / 2)) * 180) / M_PI;
    res.humerus = ((req.humerus + (M_PI / 2)) * 180) / M_PI;
    res.forearm = ((req.forearm + (M_PI / 2)) * 180) / M_PI;
    res.left_gear = (req.left_gear * 180) / M_PI;
    res.right_gear = (req.right_gear * 180) / M_PI;
    res.gripper = (req.gripper * 180) / M_PI;
    res.ubracket = ((req.ubracket + (M_PI / 2)) * 180) / M_PI;       
    res.endeffector = (req.endeffector * 180) / M_PI;                
    return true;
}

bool convert_degrees_to_radians(arm_controller::AnglesConverter::Request &req,
                                arm_controller::AnglesConverter::Response &res) {
    res.base = ((req.base * M_PI) / 180) - (M_PI / 2);
    res.humerus = ((req.humerus * M_PI) / 180) - (M_PI / 2);
    res.forearm = ((req.forearm * M_PI) / 180) - (M_PI / 2);
    res.left_gear = (req.left_gear * M_PI) / 180;
    res.right_gear = (req.right_gear * M_PI) / 180;
    res.gripper = (req.gripper * M_PI) / 180;
    res.ubracket = ((req.ubracket * M_PI) / 180) - (M_PI / 2);       
    res.endeffector = (req.endeffector * M_PI) / 180;                
    return true;
}

int main(int argc, char **argv) {
    ros::init(argc, argv, "angles_converter_cpp");

    ros::NodeHandle nh("/deltabot");

    ros::ServiceServer rad_to_deg = nh.advertiseService("radians_to_degrees", convert_radians_to_degrees);
    ros::ServiceServer deg_to_rad = nh.advertiseService("degrees_to_radians", convert_degrees_to_radians);

    ROS_INFO("Servicio de conversión activo (C++) en namespace deltabot");
    ros::spin();

    return 0;
}
