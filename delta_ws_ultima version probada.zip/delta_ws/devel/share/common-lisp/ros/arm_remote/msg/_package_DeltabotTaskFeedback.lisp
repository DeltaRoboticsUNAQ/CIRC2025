(cl:in-package arm_remote-msg)
(cl:export '(CURRENT_STEP-VAL
          CURRENT_STEP
))