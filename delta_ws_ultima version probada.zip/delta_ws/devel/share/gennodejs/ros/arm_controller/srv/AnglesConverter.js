// Auto-generated. Do not edit!

// (in-package arm_controller.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class AnglesConverterRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.base = null;
      this.humerus = null;
      this.forearm = null;
      this.left_gear = null;
      this.right_gear = null;
      this.gripper = null;
      this.ubracket = null;
      this.endeffector = null;
    }
    else {
      if (initObj.hasOwnProperty('base')) {
        this.base = initObj.base
      }
      else {
        this.base = 0.0;
      }
      if (initObj.hasOwnProperty('humerus')) {
        this.humerus = initObj.humerus
      }
      else {
        this.humerus = 0.0;
      }
      if (initObj.hasOwnProperty('forearm')) {
        this.forearm = initObj.forearm
      }
      else {
        this.forearm = 0.0;
      }
      if (initObj.hasOwnProperty('left_gear')) {
        this.left_gear = initObj.left_gear
      }
      else {
        this.left_gear = 0.0;
      }
      if (initObj.hasOwnProperty('right_gear')) {
        this.right_gear = initObj.right_gear
      }
      else {
        this.right_gear = 0.0;
      }
      if (initObj.hasOwnProperty('gripper')) {
        this.gripper = initObj.gripper
      }
      else {
        this.gripper = 0.0;
      }
      if (initObj.hasOwnProperty('ubracket')) {
        this.ubracket = initObj.ubracket
      }
      else {
        this.ubracket = 0.0;
      }
      if (initObj.hasOwnProperty('endeffector')) {
        this.endeffector = initObj.endeffector
      }
      else {
        this.endeffector = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type AnglesConverterRequest
    // Serialize message field [base]
    bufferOffset = _serializer.float64(obj.base, buffer, bufferOffset);
    // Serialize message field [humerus]
    bufferOffset = _serializer.float64(obj.humerus, buffer, bufferOffset);
    // Serialize message field [forearm]
    bufferOffset = _serializer.float64(obj.forearm, buffer, bufferOffset);
    // Serialize message field [left_gear]
    bufferOffset = _serializer.float64(obj.left_gear, buffer, bufferOffset);
    // Serialize message field [right_gear]
    bufferOffset = _serializer.float64(obj.right_gear, buffer, bufferOffset);
    // Serialize message field [gripper]
    bufferOffset = _serializer.float64(obj.gripper, buffer, bufferOffset);
    // Serialize message field [ubracket]
    bufferOffset = _serializer.float64(obj.ubracket, buffer, bufferOffset);
    // Serialize message field [endeffector]
    bufferOffset = _serializer.float64(obj.endeffector, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type AnglesConverterRequest
    let len;
    let data = new AnglesConverterRequest(null);
    // Deserialize message field [base]
    data.base = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [humerus]
    data.humerus = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [forearm]
    data.forearm = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [left_gear]
    data.left_gear = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [right_gear]
    data.right_gear = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [gripper]
    data.gripper = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [ubracket]
    data.ubracket = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [endeffector]
    data.endeffector = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 64;
  }

  static datatype() {
    // Returns string type for a service object
    return 'arm_controller/AnglesConverterRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b0e8dcb040e4981efdc9b93c333eb747';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Request (radians input)
    float64 base
    float64 humerus
    float64 forearm
    float64 left_gear
    float64 right_gear
    float64 gripper
    float64 ubracket
    float64 endeffector
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new AnglesConverterRequest(null);
    if (msg.base !== undefined) {
      resolved.base = msg.base;
    }
    else {
      resolved.base = 0.0
    }

    if (msg.humerus !== undefined) {
      resolved.humerus = msg.humerus;
    }
    else {
      resolved.humerus = 0.0
    }

    if (msg.forearm !== undefined) {
      resolved.forearm = msg.forearm;
    }
    else {
      resolved.forearm = 0.0
    }

    if (msg.left_gear !== undefined) {
      resolved.left_gear = msg.left_gear;
    }
    else {
      resolved.left_gear = 0.0
    }

    if (msg.right_gear !== undefined) {
      resolved.right_gear = msg.right_gear;
    }
    else {
      resolved.right_gear = 0.0
    }

    if (msg.gripper !== undefined) {
      resolved.gripper = msg.gripper;
    }
    else {
      resolved.gripper = 0.0
    }

    if (msg.ubracket !== undefined) {
      resolved.ubracket = msg.ubracket;
    }
    else {
      resolved.ubracket = 0.0
    }

    if (msg.endeffector !== undefined) {
      resolved.endeffector = msg.endeffector;
    }
    else {
      resolved.endeffector = 0.0
    }

    return resolved;
    }
};

class AnglesConverterResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.base = null;
      this.humerus = null;
      this.forearm = null;
      this.left_gear = null;
      this.right_gear = null;
      this.gripper = null;
      this.ubracket = null;
      this.endeffector = null;
    }
    else {
      if (initObj.hasOwnProperty('base')) {
        this.base = initObj.base
      }
      else {
        this.base = 0.0;
      }
      if (initObj.hasOwnProperty('humerus')) {
        this.humerus = initObj.humerus
      }
      else {
        this.humerus = 0.0;
      }
      if (initObj.hasOwnProperty('forearm')) {
        this.forearm = initObj.forearm
      }
      else {
        this.forearm = 0.0;
      }
      if (initObj.hasOwnProperty('left_gear')) {
        this.left_gear = initObj.left_gear
      }
      else {
        this.left_gear = 0.0;
      }
      if (initObj.hasOwnProperty('right_gear')) {
        this.right_gear = initObj.right_gear
      }
      else {
        this.right_gear = 0.0;
      }
      if (initObj.hasOwnProperty('gripper')) {
        this.gripper = initObj.gripper
      }
      else {
        this.gripper = 0.0;
      }
      if (initObj.hasOwnProperty('ubracket')) {
        this.ubracket = initObj.ubracket
      }
      else {
        this.ubracket = 0.0;
      }
      if (initObj.hasOwnProperty('endeffector')) {
        this.endeffector = initObj.endeffector
      }
      else {
        this.endeffector = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type AnglesConverterResponse
    // Serialize message field [base]
    bufferOffset = _serializer.float64(obj.base, buffer, bufferOffset);
    // Serialize message field [humerus]
    bufferOffset = _serializer.float64(obj.humerus, buffer, bufferOffset);
    // Serialize message field [forearm]
    bufferOffset = _serializer.float64(obj.forearm, buffer, bufferOffset);
    // Serialize message field [left_gear]
    bufferOffset = _serializer.float64(obj.left_gear, buffer, bufferOffset);
    // Serialize message field [right_gear]
    bufferOffset = _serializer.float64(obj.right_gear, buffer, bufferOffset);
    // Serialize message field [gripper]
    bufferOffset = _serializer.float64(obj.gripper, buffer, bufferOffset);
    // Serialize message field [ubracket]
    bufferOffset = _serializer.float64(obj.ubracket, buffer, bufferOffset);
    // Serialize message field [endeffector]
    bufferOffset = _serializer.float64(obj.endeffector, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type AnglesConverterResponse
    let len;
    let data = new AnglesConverterResponse(null);
    // Deserialize message field [base]
    data.base = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [humerus]
    data.humerus = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [forearm]
    data.forearm = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [left_gear]
    data.left_gear = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [right_gear]
    data.right_gear = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [gripper]
    data.gripper = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [ubracket]
    data.ubracket = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [endeffector]
    data.endeffector = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 64;
  }

  static datatype() {
    // Returns string type for a service object
    return 'arm_controller/AnglesConverterResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b0e8dcb040e4981efdc9b93c333eb747';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Response (degrees output)
    float64 base
    float64 humerus
    float64 forearm
    float64 left_gear
    float64 right_gear
    float64 gripper
    float64 ubracket
    float64 endeffector
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new AnglesConverterResponse(null);
    if (msg.base !== undefined) {
      resolved.base = msg.base;
    }
    else {
      resolved.base = 0.0
    }

    if (msg.humerus !== undefined) {
      resolved.humerus = msg.humerus;
    }
    else {
      resolved.humerus = 0.0
    }

    if (msg.forearm !== undefined) {
      resolved.forearm = msg.forearm;
    }
    else {
      resolved.forearm = 0.0
    }

    if (msg.left_gear !== undefined) {
      resolved.left_gear = msg.left_gear;
    }
    else {
      resolved.left_gear = 0.0
    }

    if (msg.right_gear !== undefined) {
      resolved.right_gear = msg.right_gear;
    }
    else {
      resolved.right_gear = 0.0
    }

    if (msg.gripper !== undefined) {
      resolved.gripper = msg.gripper;
    }
    else {
      resolved.gripper = 0.0
    }

    if (msg.ubracket !== undefined) {
      resolved.ubracket = msg.ubracket;
    }
    else {
      resolved.ubracket = 0.0
    }

    if (msg.endeffector !== undefined) {
      resolved.endeffector = msg.endeffector;
    }
    else {
      resolved.endeffector = 0.0
    }

    return resolved;
    }
};

module.exports = {
  Request: AnglesConverterRequest,
  Response: AnglesConverterResponse,
  md5sum() { return 'dfc2cc33b126743629da60b75925eb1a'; },
  datatype() { return 'arm_controller/AnglesConverter'; }
};
