(cl:in-package arm_remote-msg)
(cl:export '(HEADER-VAL
          HEADER
          STATUS-VAL
          STATUS
          RESULT-VAL
          RESULT
))