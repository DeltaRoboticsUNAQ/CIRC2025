(cl:in-package arm_remote-msg)
(cl:export '(HEADER-VAL
          HEADER
          GOAL_ID-VAL
          GOAL_ID
          GOAL-VAL
          GOAL
))