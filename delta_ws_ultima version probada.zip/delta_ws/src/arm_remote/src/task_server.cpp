#include <ros/ros.h>
#include <actionlib/server/simple_action_server.h>
#include <arm_remote/DeltabotTaskAction.h>
#include <serial/serial.h>
#include <sstream>
#include <algorithm>
#include <std_msgs/Float64MultiArray.h>

double mapToRadians(double x, double in_min, double in_max, double out_min, double out_max)
{
    x = std::max(in_min, std::min(in_max, x));
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

class DeltabotTaskServer
{
protected:
  ros::NodeHandle nh_;
  actionlib::SimpleActionServer<arm_remote::DeltabotTaskAction> as_;
  std::string action_name_;
  arm_remote::DeltabotTaskResult result_;
  ros::Publisher command_pub_;
  serial::Serial serial_port_;
  bool arduino_connected_;

public:
  DeltabotTaskServer(std::string name)
      : as_(nh_, name, boost::bind(&DeltabotTaskServer::executeCB, this, _1), false),
        action_name_(name), arduino_connected_(false)
  {
    command_pub_ = nh_.advertise<std_msgs::Float64MultiArray>("/deltabot/command_raw", 10);

    try {
      serial_port_.setPort("/dev/ttyACM0");
      serial_port_.setBaudrate(9600);
      serial::Timeout to = serial::Timeout::simpleTimeout(1000);
      serial_port_.setTimeout(to);
      serial_port_.open();

      if (serial_port_.isOpen()) {
        arduino_connected_ = true;
        ROS_INFO("Conexion serial con Arduino establecida.");
      } else {
        ROS_WARN("No se pudo abrir el puerto serial. Continuando sin Arduino.");
      }
    } catch (serial::IOException& e) {
      ROS_WARN("Excepcion al abrir el puerto serial: %s", e.what());
      arduino_connected_ = false;
    }

    as_.start();
  }

  void executeCB(const arm_remote::DeltabotTaskGoalConstPtr &goal)
  {
    const std::string& group = goal->target_group;
    const std::vector<double>& pos = goal->target_position;

    std_msgs::Float64MultiArray cmd_msg;
    cmd_msg.data.resize(8, 0.0);  // Asegura que haya espacio para todos los grupos

    std::stringstream ss;

    if (group == "arm")
    {
      if (pos.size() < 3) {
        result_.success = false;
        as_.setAborted(result_, "Se requieren 3 posiciones para el grupo 'arm'.");
        return;
      }

      cmd_msg.data[0] = mapToRadians(pos[2], 0, 1023, -M_PI, M_PI);  // bracket_joint
      cmd_msg.data[1] = pos[0];  // humerus
      cmd_msg.data[2] = pos[1];  // forearm
      command_pub_.publish(cmd_msg);

      int pwm1 = static_cast<int>(std::round(pos[0]));
      int pwm2 = static_cast<int>(std::round(pos[1]));
      int pwm3 = static_cast<int>(std::round(pos[2]));

      ss << "A" << pwm1 << "," << pwm2 << "," << pwm3 << "\n";
    }
    else if (group == "wrist")
    {
      if (pos.size() < 2) {
        result_.success = false;
        as_.setAborted(result_, "Se requieren 2 posiciones para el grupo 'wrist'.");
        return;
      }

      cmd_msg.data[6] = mapToRadians(pos[0], 0, 1023, -M_PI_2, M_PI_2);
      cmd_msg.data[7] = mapToRadians(pos[1], 0, 1023, -M_PI, M_PI);
      command_pub_.publish(cmd_msg);

      int pwm1 = static_cast<int>(std::round(pos[0]));
      int pwm2 = static_cast<int>(std::round(pos[1]));

      ss << "W" << pwm1 << "," << pwm2 << "\n";
    }
    else if (group == "gripper")
    {
      if (pos.size() < 1) {
        result_.success = false;
        as_.setAborted(result_, "Se requiere 1 posicion para el grupo 'gripper'.");
        return;
      }

      cmd_msg.data[5] = pos[0];
      command_pub_.publish(cmd_msg);

      int pwm = static_cast<int>(std::round(pos[0]));
      ss << "G" << pwm << "\n";
    }
    else
    {
      ROS_WARN("Grupo invalido: %s", group.c_str());
      result_.success = false;
      as_.setAborted(result_, "Grupo invalido.");
      return;
    }

    std::string mensaje = ss.str();

    if (arduino_connected_) {
      try {
        serial_port_.write(mensaje);
        ROS_INFO("Enviado a Arduino: %s", mensaje.c_str());

        ros::Duration(0.2).sleep();
        if (serial_port_.available()) {
          std::string respuesta = serial_port_.readline(100, "\n");
          ROS_INFO("Arduino respondió: %s", respuesta.c_str());
        } else {
          ROS_WARN("Arduino no respondió.");
        }
      } catch (serial::IOException& e) {
        ROS_WARN("Error al enviar al Arduino: %s", e.what());
      }
    } else {
      ROS_WARN("Arduino no conectado. Comando '%s' no fue enviado por serial.", mensaje.c_str());
    }

    ros::Duration(0.5).sleep();
    result_.success = true;
    as_.setSucceeded(result_);
  }
};

int main(int argc, char **argv)
{
  ros::init(argc, argv, "deltabot_task_server");
  DeltabotTaskServer server("deltabot_task");
  ros::spin();
  return 0;
}
