# generated from genmsg/cmake/pkg-msg-paths.cmake.develspace.in

set(arm_remote_MSG_INCLUDE_DIRS "/home/torres/delta_ws/devel/share/arm_remote/msg")
set(arm_remote_MSG_DEPENDENCIES std_msgs;actionlib_msgs)
