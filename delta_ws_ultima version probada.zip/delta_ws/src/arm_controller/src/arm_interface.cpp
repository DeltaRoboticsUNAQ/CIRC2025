#include "arm_interface.h"
#include <std_msgs/Int16MultiArray.h>
#include "arm_controller/AnglesConverter.h"
#include <cmath>

ArmInterface::ArmInterface(ros::NodeHandle& nh) : nh_(nh),
            pnh_("~"),
            pos_(9, 0),
            vel_(9, 0),
            eff_(9, 0),
            cmd_(9, 0),
            last_cmd_(9, 0),
            names_{"bracket_joint", "humerus_low_joint", "forearm_low_joint", 
                   "left_gear_joint", "right_gear_joint", "gripper", 
                   "ubracket_joint", "endeffector_joint"}
{
    pnh_.param("joint_names", names_, names_);

    hardware_pub_ = pnh_.advertise<std_msgs::Int16MultiArray>("/delta/arm_actuate", 1000);
    hardware_srv_ = pnh_.serviceClient<arm_controller::AnglesConverter>("/deltabot/radians_to_degrees");

    command_sub_ = pnh_.subscribe("/deltabot/command_raw", 10, &ArmInterface::commandCallback, this);

    last_publish_time_ = ros::Time::now();

    ROS_INFO("Starting Arm Hardware Interface (gripper included in control)...");

    for (size_t i = 0; i < names_.size(); ++i)
    {
        hardware_interface::JointStateHandle state_handle(names_[i], &pos_[i], &vel_[i], &eff_[i]);
        joint_state_interface_.registerHandle(state_handle);

        hardware_interface::JointHandle position_handle(joint_state_interface_.getHandle(names_[i]), &cmd_[i]);
        joint_position_interface_.registerHandle(position_handle);
    }

    registerInterface(&joint_state_interface_);
    registerInterface(&joint_position_interface_);

    controller_manager_.reset(new controller_manager::ControllerManager(this, nh_));
    update_freq_ = ros::Duration(0.1);
    looper_ = nh_.createTimer(update_freq_, &ArmInterface::update, this);
}

void ArmInterface::update(const ros::TimerEvent& e)
{
    elapsed_time_ = ros::Duration(e.current_real - e.last_real);
    read();
    controller_manager_->update(ros::Time::now(), elapsed_time_);
    write(elapsed_time_);
}

void ArmInterface::read()
{
    for (size_t i = 0; i < pos_.size(); ++i)
    {
        pos_[i] = cmd_[i];
    }
}

void ArmInterface::write(ros::Duration elapsed_time)
{
    double base_angle     = cmd_[0];
    double humerus_angle  = cmd_[1];
    double forearm_angle  = cmd_[2];
    double gripper_angle  = cmd_[5];
    double ubracket       = std::max(-M_PI_2, std::min(cmd_[6], M_PI_2));
    double endeffector    = std::max(-M_PI, std::min(cmd_[7], M_PI));
    double left           = ubracket + endeffector;
    double right          = endeffector - ubracket;

    cmd_[3] = left;
    cmd_[4] = right;

    double L1_base = 0.1, L1_arm = 0.2;
    double L2_base = 0.1, L2_arm = 0.2;

    double humerus_piston = sqrt(L1_base*L1_base + L1_arm*L1_arm - 2*L1_base*L1_arm*cos(M_PI - humerus_angle));
    double forearm_piston = sqrt(L2_base*L2_base + L2_arm*L2_arm - 2*L2_base*L2_arm*cos(M_PI - forearm_angle));

    bool cambio_base       = std::abs(cmd_[0] - last_cmd_[0]) > 0.1;
    bool cambio_humerus    = std::abs(cmd_[1] - last_cmd_[1]) > 0.1;
    bool cambio_forearm    = std::abs(cmd_[2] - last_cmd_[2]) > 0.1;
    bool cambio_gripper    = std::abs(cmd_[5] - last_cmd_[5]) > 0.1;
    bool cambio_ubracket   = std::abs(cmd_[6] - last_cmd_[6]) > 0.1;
    bool cambio_endeff     = std::abs(cmd_[7] - last_cmd_[7]) > 0.1;

    bool should_publish = cambio_base || cambio_humerus || cambio_forearm || 
                          cambio_gripper || cambio_ubracket || cambio_endeff;

    if (ros::Time::now() - last_publish_time_ < ros::Duration(1.0))
        should_publish = false;

    if (should_publish)
    {
        last_cmd_ = cmd_;
        last_publish_time_ = ros::Time::now();

        arm_controller::AnglesConverter srv;
        srv.request.base         = base_angle;
        srv.request.humerus      = humerus_angle;
        srv.request.forearm      = forearm_angle;
        srv.request.left_gear    = left;
        srv.request.right_gear   = right;
        srv.request.gripper      = gripper_angle;
        srv.request.ubracket     = ubracket;
        srv.request.endeffector  = endeffector;

        if (hardware_srv_.call(srv))
        {
            std::vector<short int> angles_deg = {
                static_cast<short int>(std::round(srv.response.base)),
                static_cast<short int>(std::round(srv.response.humerus)),
                static_cast<short int>(std::round(srv.response.forearm)),
                static_cast<short int>(std::round(srv.response.left_gear)),
                static_cast<short int>(std::round(srv.response.right_gear)),
                static_cast<short int>(std::round(srv.response.gripper)),
                static_cast<short int>(std::round(srv.response.ubracket)),
                static_cast<short int>(std::round(srv.response.endeffector))
            };

            std_msgs::Int16MultiArray msg;
            msg.layout.dim.push_back(std_msgs::MultiArrayDimension());
            msg.layout.dim[0].size = angles_deg.size();
            msg.layout.dim[0].stride = 1;
            msg.layout.dim[0].label = "joints";
            msg.data = angles_deg;

            hardware_pub_.publish(msg);

            ROS_INFO_STREAM("Publicado al hardware (grados): base=" << srv.response.base
                                  << ", humerus=" << srv.response.humerus
                                  << ", forearm=" << srv.response.forearm
                                  << ", left=" << srv.response.left_gear
                                  << ", right=" << srv.response.right_gear
                                  << ", gripper=" << srv.response.gripper
                                  << ", ubracket=" << srv.response.ubracket
                                  << ", endeffector=" << srv.response.endeffector);
        }
        else
        {
            ROS_ERROR("Failed to call service radians_to_degrees");
        }
    }
}

void ArmInterface::commandCallback(const std_msgs::Float64MultiArray::ConstPtr& msg)
{
    size_t n = std::min(cmd_.size(), msg->data.size());
    for (size_t i = 0; i < n; ++i)
        cmd_[i] = msg->data[i];

    ROS_INFO_STREAM("Comando recibido desde /deltabot/command_raw.");
}

int main(int argc, char** argv)
{
    ros::init(argc, argv, "arm_interface_node");
    ros::NodeHandle nh;
    ros::MultiThreadedSpinner spinner(2);  
    ArmInterface robot(nh);
    spinner.spin();
    return 0;
}
