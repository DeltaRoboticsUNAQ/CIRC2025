
"use strict";

let DeltabotTaskActionGoal = require('./DeltabotTaskActionGoal.js');
let DeltabotTaskActionResult = require('./DeltabotTaskActionResult.js');
let DeltabotTaskResult = require('./DeltabotTaskResult.js');
let DeltabotTaskGoal = require('./DeltabotTaskGoal.js');
let DeltabotTaskActionFeedback = require('./DeltabotTaskActionFeedback.js');
let DeltabotTaskAction = require('./DeltabotTaskAction.js');
let DeltabotTaskFeedback = require('./DeltabotTaskFeedback.js');

module.exports = {
  DeltabotTaskActionGoal: DeltabotTaskActionGoal,
  DeltabotTaskActionResult: DeltabotTaskActionResult,
  DeltabotTaskResult: DeltabotTaskResult,
  DeltabotTaskGoal: DeltabotTaskGoal,
  DeltabotTaskActionFeedback: DeltabotTaskActionFeedback,
  DeltabotTaskAction: DeltabotTaskAction,
  DeltabotTaskFeedback: DeltabotTaskFeedback,
};
